# TaskMaster

## Android App

![lab29](screenshots/lab291.png)
![lab29](screenshots/lab292.png)
![lab29](screenshots/lab293.png)

![lab28](screenshots/lab281.png)
![lab28](screenshots/lab282.png)
![homebefore](screenshots/homebefore.png)
![homeafter](screenshots/homeAfter.png)
![settings](screenshots/settings.png)
![details1](screenshots/details1.png)
![details2](screenshots/details2.png)
![details3](screenshots/details3.png)